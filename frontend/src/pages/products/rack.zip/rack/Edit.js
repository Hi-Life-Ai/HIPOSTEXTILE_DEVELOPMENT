

import React, { useState, useContext, useEffect } from 'react';
import { Box, Button, Grid, FormControl, OutlinedInput, InputLabel, Typography, Dialog, DialogContent, DialogActions, } from '@mui/material';
import { userStyle, colourStyles } from '../../PageStyle';
import Selects from "react-select";
import { FaPlus } from 'react-icons/fa';
import { AiOutlineClose } from 'react-icons/ai';
import axios from 'axios';
import { useNavigate, Link, useParams } from 'react-router-dom';
import { toast } from 'react-toastify';
import Navbar from '../../../components/header/Navbar';
import ErrorOutlineOutlinedIcon from '@mui/icons-material/ErrorOutlineOutlined';
import { UserRoleAccessContext } from '../../../context/Appcontext';
import Footer from '../../../components/footer/Footer';
import { SERVICE } from '../../../services/Baseservice';
import { AuthContext } from '../../../context/Appcontext';
import Headtitle from '../../../components/header/Headtitle';

function Rackeditlist() {

    const { auth, setngs } = useContext(AuthContext);
    const [busilocations, setBusilocations] = useState();
    const [isBusilocations, setIsBusilocations] = useState();
    const [rack, setRack] = useState({ businesslocation: "", mainrack: "", subrack:"" })
    const [todos, setTodos] = useState([]);
    const [check, setCheck] = useState([]);
    const [inputValues, setInputValues] = useState({ subrackcode: '', });

    //access...
    const { allLocations, isActiveLocations } = useContext(UserRoleAccessContext);

    // check edit
    const [overAllRack, setOverAllRack] = useState("")
    const [getDepartment, setGetDepartment] = useState("")
    const [EditDepCount, setEditDepCount] = useState(0)

    // Error Popup model
    const [isErrorOpenpop, setIsErrorOpenpop] = useState(false);
    const [showAlertpop, setShowAlertpop] = useState();
    const handleClickOpenerrpop = () => { setIsErrorOpenpop(true); };
    const handleCloseerrpop = () => { setIsErrorOpenpop(false); };

    // Pop up error
    const [isErrorOpen, setIsErrorOpen] = useState(false);
    const [showAlert, setShowAlert] = useState()
    const handleClose = () => { setIsErrorOpen(false); };
    const handleClickOpenc = () => { setIsErrorOpen(true); };
    const handleInputChange = (event) => { setInputValues({ ...inputValues, subrackcode: event }); };

    const handleAddTodo = () => {
        if(rack.subrack == "" || rack.subrack == undefined){
            setShowAlert("Please Enter SubRack!");
            handleClickOpenc();
        }else{
            const newTodo = { subrackcode: rack.mainrack + rack.subrack, };

            if(check.includes(newTodo?.subrackcode)){
                setShowAlert("Rack Already Exists");
                handleClickOpenc();
                setRack({ ...rack, subrack: "" });
            }else{
                setTodos([...todos, newTodo]);
                setCheck([...check, newTodo?.subrackcode]);
            }
        }
    };

    const handleFileDelete = (index) => { setTodos((prevFiles) => prevFiles?.filter((_, i) => i !== index)); };

    const backLPage = useNavigate();

    // Location
    const fetchLocation = async () => {
        try {
            let selectlocation = allLocations?.length > 0 && allLocations.filter((data, index) => {
                return data.locationid == setngs.businesslocation
            })
            setIsBusilocations(selectlocation[0]);
            setBusilocations(isActiveLocations?.map((d) => (
                {
                    ...d,
                    label: d.name,
                    value: d.locationid,
                }
            )));
        } catch (err) {
            const messages = err?.response?.data?.message;
            if (messages) {
                toast.error(messages);
            } else {
                toast.error("Something went wrong!")
            }
        }
    };

    useEffect(() => { fetchLocation(); }, []);

    const id = useParams().id;

    // Get Datas
    const fetchHandler = async () => {
        try {
            let response = await axios.get(`${SERVICE.RACK_SINGLE}/${id}`, {
                headers: {
                    'Authorization': `Bearer ${auth.APIToken}`
                },
            });
            setRack(response?.data?.srack);
            // getEditId(response?.data?.srack?.combinerack || []);
            getEditId(response?.data?.srack?.combinerack);
            setGetDepartment(response?.data?.srack?.combinerack?.map(t => t.subrackcode))
            setTodos(response?.data?.srack?.combinerack || []);
            let arr = [];
            let resdata = response?.data?.srack?.combinerack.map((t) => {
                return t.subrackcode
            });
            setCheck(resdata)
        } catch (err) {
            const messages = err?.response?.data?.message;
            if (messages) {
                toast.error(messages);
            } else {
                toast.error("Something went wrong!")
            }
        }
    };

    useEffect(() => { fetchHandler(); }, [id]);

    const getEditId = async (value) => {

        // let subrackCodes = [];
        // value.forEach(subrack => {
        //     subrackCodes.push(subrack.subrackcode);
        // });

        // let formattedSubrackCodes = subrackCodes.join('\n');

        try {
            let res = await axios.post(SERVICE.RACK_EDIT, {
                headers: {
                    'Authorization': `Bearer ${auth.APIToken}`
                },
                businessid: String(setngs.businessid),
                rack: [...value]
            });
            setEditDepCount(res?.data?.products?.length)
            setOverAllRack(`The ${value?.filter(t => t.subrackcode)} is linked in ${res?.data?.products?.length > 0 ? "Product ," : ""} whether you want to do changes ..??`)
        } catch (err) {
            const messages = err?.response?.data?.message;
            if (messages) {
                toast.error(messages);
            } else {
                toast.error("Something went wrong!")
            }
        }
    };

    const getOverAllRackUpdate = async () => {
        try {
            let res = await axios.post(SERVICE.RACK_EDIT, {
                headers: {
                    'Authorization': `Bearer ${auth.APIToken}`
                },
                businessid: String(setngs.businessid),
                rack: getDepartment

            });
            editOveAllRack(res.data.products)
        }
        catch (err) {
            const messages = err?.response?.data?.message
            if (messages) {
                toast.error(messages);
            } else {
                toast.error("Something went wrong!")
            }

        }
    };

    const editOveAllRack = async (products) => {
        try {

            // if (products.length > 0) {
            //     let result = products.map((data, index) => {                    
            //         let request = axios.put(`${SERVICE.PRODUCT_SINGLE}/${data._id}`, {
            //             headers: {
            //                 'Authorization': `Bearer ${auth.APIToken}`
            //             },
            //             rack: String(),
            //         });
            //     })
            // }
            if (products?.length > 0) {
                todos.forEach(todoItem => {
                    todoItem.combinerack.forEach(subrack => {
                        let subrackcode = subrack.subrackcode;

                        // Find the matching product by subrackcode
                        let productToUpdate = products.find(product => product.rack === subrackcode);

                        if (productToUpdate) {
                            // Update the product's rack value
                            productToUpdate.rack = 'NewRackValue'; // Replace 'NewRackValue' with the new rack value
                        }
                    });
                });

                // Now you can perform your API calls to update the products
                products.forEach(product => {
                    let request = axios.put(`${SERVICE.PRODUCT_SINGLE}/${product._id}`, {
                        rack: product.rack
                    }, {
                        headers: {
                            'Authorization': `Bearer ${auth.APIToken}`
                        }
                    });
                });
            }
        } catch (err) {
            const messages = err?.response?.data?.message
            if (messages) {
                toast.error(messages);
            } else {
                toast.error("Something went wrong!")
            }
        }
    }

    // store category data to db
    const sendRequest = async () => {
        try {
            let res = await axios.put(`${SERVICE.RACK_SINGLE}/${id}`, {
                headers: {
                    'Authorization': `Bearer ${auth.APIToken}`
                },
                businesslocation: String(rack.businesslocation),
                mainrack: String(rack.mainrack),
                combinerack: [...todos],
                assignbusinessid: String(setngs.businessid),
            });
            await getOverAllRackUpdate()
            setRack(res.data);
            handleClose();
            toast.success(res.data.message, {
                position: toast.POSITION.TOP_CENTER
            });
            backLPage('/product/rack/list');
        } catch (err) {
            const messages = err?.response?.data?.message;
            if (messages) {
                setShowAlert(messages);
                handleClickOpenc();
            } else {
                setShowAlert("Something went wrong!");
                handleClickOpenc();
            }
        }
    };

    const editSubmit = (e) => {
        e.preventDefault();
        if (rack.businesslocation == "") {
            setShowAlert("Please select bussiness location!");
            handleClickOpenc();
        } else if (rack.mainrack == "") {
            setShowAlert("Please enter main rack!");
            handleClickOpenc();
        } else if (todos.length == 0) {
            setShowAlert("Please enter any one of sub rack!");
            handleClickOpenc();
        }
        else {
            sendRequest();
        }
    }

    return (
        <Box>
            <Headtitle title={'Edit Rack'} />
            <Typography sx={userStyle.HeaderText}>Edit Rack</Typography>
            {/* content start */}
            <form>
                <Box sx={userStyle.container}>
                    <Grid container spacing={3} sx={userStyle.textInput}>
                        <Grid item md={6} sm={12} xs={12}>
                            <InputLabel id="demo-select-small">Business Location  <b style={{ color: 'red', }}>*</b></InputLabel>
                            <FormControl size="small" fullWidth>
                                <Selects
                                    options={busilocations}
                                    styles={colourStyles}
                                    placeholder={isBusilocations ? isBusilocations.name : ""}
                                    onChange={(e) => { setRack({ ...rack, businesslocation: e.value }); }}
                                />
                            </FormControl>
                        </Grid>
                        <Grid item md={6} sm={12} xs={12}>
                            <InputLabel htmlFor="component-outlined">Main Rack <b style={{ color: 'red', }}>*</b></InputLabel>
                            <FormControl size="small" fullWidth>
                                <OutlinedInput
                                    id="component-outlined"
                                    type="text"
                                    name="mainrack"
                                    value={rack.mainrack}
                                    onChange={(e) => {
                                        setRack({ ...rack, mainrack: e.target.value.toUpperCase(), });
                                    }}
                                />
                            </FormControl>
                        </Grid>
                        <Grid item lg={5} md={5} sm={10} xs={10}>
                            <InputLabel htmlFor="component-outlined">Sub Rack <b style={{ color: 'red', }}>*</b> </InputLabel>
                            <FormControl size="small" fullWidth>
                                <OutlinedInput
                                    type="text"
                                    sx={userStyle.input}
                                    name="subrack"
                                    value={rack.subrack}
                                    onChange={(e) => { setRack({ ...rack, subrack: e.target.value }); handleInputChange(e.target.value); }}
                                    placeholder="Enter a Sub Rack"
                                />
                            </FormControl>
                        </Grid>
                        <Grid item md={2} sm={2} xs={2}>
                            <Button variant="contained" color="success" type="button" onClick={handleAddTodo} sx={userStyle.categoryadd}><FaPlus /></Button>&nbsp;
                        </Grid>
                    </Grid><br />
                    <ul type="none" className="todoLlistUl" style={{ paddingLeft: '0px', marginLeft: '0px' }}>
                        {todos.map((item, index) => (
                            <li key={index}>
                                <br />
                                <Grid container>
                                    <Grid item sm={8} xs={12} md={6} lg={5} sx={{ display: "flex", justifyContent: "center" }}>
                                        <FormControl size="small" fullWidth>
                                            <Typography>
                                                {item.subrackcode}
                                            </Typography>
                                        </FormControl>
                                        <Button variant="contained" color="error" type="button" onClick={() => handleFileDelete(index)} sx={{ height: '30px', minWidth: '30px', marginTop: '4px', padding: '6px 10px' }}>
                                            <AiOutlineClose />
                                        </Button>
                                    </Grid>
                                </Grid>
                            </li>
                        ))}
                    </ul>
                    <InputLabel id="demo-select-small">Display Rack</InputLabel><br />
                    <Grid container sx={{ display: "flex", }} >
                        {todos.map((item, index) => {
                            return (
                                <Grid spacing={2} item lg={1} md={1} sm={2} xs={2} >

                                    <Typography sx={{ border: "1px solid #1976d2", textAlign: "center", paddingTop: "20px", paddingBottom: "20px" }} >
                                        {item.subrackcode}
                                    </Typography>
                                </Grid>
                            )
                        })}&emsp;
                    </Grid>
                    <Grid container sx={userStyle.gridcontainer}>
                        <Grid sx={{ display: 'flex' }}>
                            <Button sx={userStyle.buttonadd} type="submit" onClick={editSubmit} >UPDATE</Button>
                            <Link to="/product/rack/list"><Button sx={userStyle.buttoncancel}>CANCEL</Button></Link>
                        </Grid>
                    </Grid>
                </Box>
            </form>
            {/* ALERT DIALOG */}
            <Box>
                <Dialog
                    open={isErrorOpen}
                    onClose={handleClose}
                    aria-labelledby="alert-dialog-title"
                    aria-describedby="alert-dialog-description"
                >
                    <DialogContent sx={{ width: '350px', textAlign: 'center', alignItems: 'center' }}>
                        <ErrorOutlineOutlinedIcon sx={{ fontSize: "80px", color: 'orange' }} />
                        <Typography variant="h6" >{showAlert}</Typography>
                    </DialogContent>
                    <DialogActions>
                        <Button variant="contained" color="error" onClick={handleClose}>ok</Button>
                    </DialogActions>
                </Dialog>
            </Box>

            {/* Check edit */}
            <Box>
                <Dialog
                    open={isErrorOpenpop}
                    onClose={handleCloseerrpop}
                    aria-labelledby="alert-dialog-title"
                    aria-describedby="alert-dialog-description"
                >
                    <DialogContent
                        sx={{ width: "350px", textAlign: "center", alignItems: "center" }}
                    >
                        <Typography variant="h6">{showAlertpop}</Typography>
                    </DialogContent>
                    <DialogActions>
                        <Button variant="contained" style={{
                            padding: '7px 13px',
                            color: 'white',
                            background: 'rgb(25, 118, 210)'
                        }} onClick={() => {
                            sendRequest();
                            handleCloseerrpop();
                        }}>
                            ok
                        </Button>
                        <Button
                            sx={userStyle.buttoncancel}
                            onClick={handleCloseerrpop}
                        >
                            Cancel
                        </Button>
                    </DialogActions>
                </Dialog>
            </Box>
        </Box>
    );
}

function Rackedit() {
    return (
        <Box>
            <Navbar /><br /><br /><br /><br /><br />
            <Box sx={{ width: '100%', overflowX: 'hidden' }}>
                <Box component="main" className='content'>
                    <Rackeditlist /><br /><br /><br /><br />
                    <Footer />
                </Box>
            </Box>
        </Box>
    );
}
export default Rackedit;