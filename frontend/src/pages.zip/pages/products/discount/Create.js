import React, { useState, useEffect, useContext } from 'react';
import { Box, Grid, FormControl, InputLabel, OutlinedInput, Button, Typography, Dialog, DialogContent, DialogActions, Select, MenuItem, } from '@mui/material';
import ErrorOutlineOutlinedIcon from '@mui/icons-material/ErrorOutlineOutlined';
import Headtitle from '../../../components/header/Headtitle';
import { AuthContext } from '../../../context/Appcontext';
import { SERVICE } from '../../../services/Baseservice';
import Footer from '../../../components/footer/Footer';
import { useNavigate } from 'react-router-dom';
import { userStyle, colourStyles } from '../../PageStyle';
import { toast } from 'react-toastify';
import Selects from 'react-select';
import { UserRoleAccessContext } from '../../../context/Appcontext';
import axios from 'axios';

const Discountcreate = () => {

    const [discounts, setDiscounts] = useState();
    const [productList, setProductList] = useState([]);
    const [busilocations, setBusilocations] = useState([]);
    const [product, setProduct] = useState({});
    const { auth, setngs } = useContext(AuthContext);
    const [locationData, setLocationData] = useState([])
    // Access
  const { isUserRoleAccess, isActiveLocations,allProducts } = useContext(UserRoleAccessContext);

    const [disAddForm, setDisAddForm] = useState({
        businesslocation: "", discountid: "", name: "", products: "", category: "", subcategory: "", brand: "", purchaseexcludetax: "",
        pruchaseincludetax: "", sellingexcludetax: "", discounttype: "None", selectdiscountprice: "Purchase Excluding Tax",
        discountamt: 0, discountvalue: 0, startsat: "", endsat: "", isactive: "",
    });

    // Popup model
    const [isErrorOpen, setIsErrorOpen] = useState(false);
    const [showAlert, setShowAlert] = useState()
    const handleClickOpen = () => { setIsErrorOpen(true); };
    const handleClose = () => { setIsErrorOpen(false); };

    // auto id for pur  chase number
    let newval = setngs ? setngs.discountsku == undefined ? "DS0001" : setngs.discountsku + "0001" : "DS0001";

    // Discounts
    const fetchDiscount = async () => {
        try {
            let res = await axios.post(SERVICE.DISCOUNT, {
                headers: {
                    'Authorization': `Bearer ${auth.APIToken}`
                },
                businessid:String(setngs.businessid),
                role:String(isUserRoleAccess.role),
                userassignedlocation:[isUserRoleAccess.businesslocation]
            });
            
            let locresult = res.data.discounts.map((data, index)=>{
                return data.discountid
            })
            setBusilocations(isActiveLocations.map((d) => (
                {
                  ...d,
                  label: d.name,
                  value: d.locationid,
                }
              )));
            setLocationData(locresult);
            setDiscounts(res?.data?.discounts);
        } catch (err) {
            const messages = err?.response?.data?.message;
            if(messages) {
                toast.error(messages);
            }else{
                toast.error("Something went wrong!")
            }
        }
    };

    // get all products based on location
    const getProducts = (e) => {
        let getcustomerallbill = allProducts?.filter((item) => {
            return e.locationid == item.businesslocation
        })
        setProductList(
            getcustomerallbill?.map((d) => ({
                ...d,
                label: d.productname,
                value: d.productname,
            }))
        );
        
    }
   
    // Search Addressone
    const searchAdd = async (id) => {
        try {
            let request = await axios.get(`${SERVICE.PRODUCT_SINGLE}/${id}`, {
                headers: {
                    'Authorization': `Bearer ${auth.APIToken}`
                }
            });
            setProduct(request?.data?.sproduct);
        }
        catch (err) {
            const messages = err?.response?.data?.message;
            if(messages) {
                toast.error(messages);
            }else{
                toast.error("Something went wrong!")
            }
        }
    };

    useEffect(
        () => {
            fetchDiscount()
        }, []
    );

    let purExc = product.purchaseexcludetax
    let purInc = product.pruchaseincludetax
    let selExc = product.sellingexcludetax

    const getDiscount = () => {

        if (disAddForm.discounttype == "None") {
            setDisAddForm({
                ...disAddForm, discountvalue: disAddForm.discountvalue
            })
        }
        if (disAddForm.discounttype == "Fixed" || disAddForm.discounttype == "Amount") {
            if (disAddForm.selectdiscountprice == "Purchase Excluding Tax") {
                setDisAddForm({
                    ...disAddForm, discountvalue: Number(purExc) - Number(disAddForm.discountamt)
                })
            }
            else if (disAddForm.selectdiscountprice == "Purchase Including Tax") {
                setDisAddForm({
                    ...disAddForm, discountvalue: Number(purInc) - Number(disAddForm.discountamt)
                })
            }
            else if (disAddForm.selectdiscountprice == "Selling Tax") {
                setDisAddForm({
                    ...disAddForm, discountvalue: Number(selExc) - Number(disAddForm.discountamt)
                })
            }
        }
        if (disAddForm.discounttype == "Percentage") {
            if (disAddForm.selectdiscountprice == "Purchase Excluding Tax") {
                setDisAddForm({
                    ...disAddForm, discountvalue: Number(purExc) - (Number(purExc) * (Number(disAddForm.discountamt) / 100))
                })
            }
            else if (disAddForm.selectdiscountprice == "Purchase Including Tax") {
                setDisAddForm({
                    ...disAddForm, discountvalue: Number(purInc) - (Number(purExc) * (Number(disAddForm.discountamt) / 100))
                })
            }
            else if (disAddForm.selectdiscountprice == "Selling Tax") {
                setDisAddForm({
                    ...disAddForm, discountvalue: Number(selExc) - (Number(purExc) * (Number(disAddForm.discountamt) / 100))
                })
            }
        }
    }

    useEffect(() => {
        getDiscount();
    }, [productList, disAddForm.discountamt, disAddForm.discountvalue])

    const bactToPage = useNavigate();

    const sendRequest = async () => {
        try {
            let req = await axios.post(SERVICE.DISCOUNT_CREATE, {
                headers: {
                    'Authorization': `Bearer ${auth.APIToken}`
                },
                businesslocation: String(disAddForm.businesslocation),
                discountid: String(newval),
                name: String(disAddForm.name),
                products: String(disAddForm.products),
                productid:String(product.sku),
                category: String(product.category),
                subcategory: String(product.subcategory),
                brand: String(product.brand),
                purchaseexcludetax: Number(product.purchaseexcludetax),
                pruchaseincludetax: Number(product.pruchaseincludetax),
                sellingvalue: Number(product.sellingexcludetax),
                discounttype: String(disAddForm.discounttype),
                selectdiscountprice: String(disAddForm.selectdiscountprice),
                discountamt: Number(disAddForm.discountamt),
                discountvalue: Number(disAddForm.discountvalue),
                startsat: String(disAddForm.startsat),
                endsat: String(disAddForm.endsat),
                assignbusinessid:String(setngs.businessid),
            });
            setDisAddForm(req.data);
            toast.success(req.data.message, {
                position: toast.POSITION.TOP_CENTER
            });
            bactToPage('/product/discount/list');
        } catch (err) {
            const messages = err?.response?.data?.message;
            if(messages) {
                toast.error(messages);
            }else{
                toast.error("Something went wrong!")
            }
        }

    }

    const handleAddSubmit = (e) => {
        e.preventDefault();
        if(locationData.includes(disAddForm.discounid)){
            setShowAlert("ID Already Exists");
            handleClickOpen();
        }
       else if (disAddForm.businesslocation == "") {
            setShowAlert("Please Select Location!")
            handleClickOpen();
        }
        else if (disAddForm.name == "") {
            setShowAlert("Please Enter Name!")
            handleClickOpen();
        }
        else if (disAddForm.products == "") {
            setShowAlert("Please Select Product Name!")
            handleClickOpen();
        }
        else if (disAddForm.discounttype == "") {
            setShowAlert("Please Select Discount Type!")
            handleClickOpen();
        }
        else if (disAddForm.discountamt == "") {
            setShowAlert("Please Enter Discount Amount!")
            handleClickOpen();
        }
        else {
            sendRequest();
        }
    }

    const handleBack = () => {
        bactToPage('/product/discount/list')
    }

    const handleValidationName = (e) => {
        let val = e.target.value;
        let numbers = new RegExp('[0-9]')
        var regExSpecialChar = /[`₹!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;
        if (e.target.value.match(numbers)) {
            setShowAlert("Please enter characters only! (A-Z or a-z)")
            handleClickOpen();
            let num = val.length;
            let value = val.slice(0, num - 1)
            setDisAddForm({ ...disAddForm, name: value })
        }
        else if (regExSpecialChar.test(e.target.value)) {
            setShowAlert("Please enter characters only! (A-Z or a-z)")
            handleClickOpen();
            let num = val.length;
            let value = val.slice(0, num - 1)
            setDisAddForm({ ...disAddForm, name: value })
        }
    }

    const handleValidationAmount = (e) => {
        let val = e.target.value;
        let alphabets = new RegExp('[a-zA-Z]')
        var regExSpecialChar = /[ `₹!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;
        if (e.target.value.match(alphabets)) {
            setShowAlert("Please enter numbers only! (0-9)")
            handleClickOpen();
            let num = val.length;
            let value = val.slice(0, num - 1)
            setDisAddForm({ ...disAddForm, discountamt: value })
        }
        else if (regExSpecialChar.test(e.target.value)) {
            setShowAlert("Please enter numbers only! (0-9)")
            handleClickOpen();
            let num = val.length;
            let value = val.slice(0, num - 1)
            setDisAddForm({ ...disAddForm, discountamt: value })
        }
    }

    return (
        <Box>
            <Headtitle title={'Add Discount'} />
            <Typography sx={userStyle.HeaderText}>Add Discount</Typography>
            <Box sx={userStyle.container}>
                <form onSubmit={handleAddSubmit}>
                    <Grid container spacing={3}>
                        {/* Grid one */}
                        <Grid item lg={3} md={4} sm={6} xs={12}>
                            <InputLabel id="demo-select-small" sx={{ display: "flex" }}>Location <b style={{ color: "red", marginLeft: "2px" }}>*</b></InputLabel>
                            <FormControl size="small" fullWidth>
                                <Selects
                                    onChange={(e) => {
                                        setDisAddForm({ ...disAddForm, businesslocation: e.value });
                                        getProducts(e);
                                    }}
                                    styles={colourStyles}
                                    options={busilocations}
                                />
                            </FormControl>
                        </Grid>
                        <Grid item lg={3} md={4} sm={6} xs={12}>
                            <InputLabel htmlFor="component-outlined">Discount Id</InputLabel>
                            <FormControl size="small" fullWidth>
                                {discounts && (
                                    discounts.map(
                                        () => {
                                            let strings = setngs ? setngs.discountsku : "DS";
                                            let refNo = discounts[discounts.length - 1].discountid;
                                            let digits = (discounts.length + 1).toString();
                                            const stringLength = refNo.length;
                                            let lastChar = refNo.charAt(stringLength - 1);
                                            let getlastBeforeChar = refNo.charAt(stringLength - 2);
                                            let getlastThreeChar = refNo.charAt(stringLength - 3);
                                            let lastBeforeChar = refNo.slice(-2);
                                            let lastThreeChar = refNo.slice(-3);
                                            let lastDigit = refNo.slice(-4);
                                            let refNOINC = parseInt(lastChar) + 1
                                            let refLstTwo = parseInt(lastBeforeChar) + 1;
                                            let refLstThree = parseInt(lastThreeChar) + 1;
                                            let refLstDigit = parseInt(lastDigit) + 1;
                                            if (digits.length < 4 && getlastBeforeChar == 0 && getlastThreeChar == 0) {
                                                refNOINC = ("000" + refNOINC).substr(-4);
                                                newval = strings + refNOINC;
                                            } else if (digits.length < 4 && getlastBeforeChar > 0 && getlastThreeChar == 0) {
                                                refNOINC = ("00" + refLstTwo).substr(-4);
                                                newval = strings + refNOINC;
                                            } else if (digits.length < 4 && getlastThreeChar > 0) {
                                                refNOINC = ("0" + refLstThree).substr(-4);
                                                newval = strings + refNOINC;
                                            } else {
                                                refNOINC = (refLstDigit).substr(-4);
                                                newval = strings + refNOINC;
                                            }
                                        }))}
                                <OutlinedInput
                                    id="component-outlined"
                                    value={newval}
                                    type="text"
                                />
                            </FormControl>
                        </Grid>
                        <Grid item lg={3} md={4} sm={6} xs={12}>
                            <InputLabel htmlFor="component-outlined" >Name <b style={{ color: "red", marginLeft: "2px" }}>*</b></InputLabel>
                            <FormControl size="small" fullWidth>
                                <OutlinedInput
                                    id="component-outlined"
                                    value={disAddForm.name}
                                    onChange={(e) => { setDisAddForm({ ...disAddForm, name: e.target.value, discountid: newval }); handleValidationName(e) }}
                                />
                            </FormControl>
                        </Grid>
                        {/* Grid two */}
                        <Grid item lg={3} md={4} sm={6} xs={12}>
                            <InputLabel htmlFor="component-outlined" >Product Name <b style={{ color: "red", marginLeft: "2px" }}>*</b></InputLabel>
                            <FormControl size="small" fullWidth>
                                <FormControl size="small" fullWidth>
                                <Selects
                                    onChange={(e) => {
                                        setDisAddForm({ ...disAddForm, products: e.value });
                                        searchAdd(e._id)
                                    }}
                                    styles={colourStyles}
                                    options={productList}
                                />
                                </FormControl>

                            </FormControl>
                        </Grid>
                        <Grid item lg={3} md={4} sm={6} xs={12}>
                            <InputLabel id="demo-select-small">Category</InputLabel>
                            <FormControl size="small" fullWidth>
                                <OutlinedInput
                                    labelId="demo-select-small"
                                    id="demo-select-small"
                                    value={product.category}
                                />
                            </FormControl>
                        </Grid>
                        <Grid item lg={3} md={4} sm={6} xs={12}>
                            <InputLabel id="demo-select-small">Sub Category</InputLabel>
                            <FormControl size="small" fullWidth>
                                <OutlinedInput
                                    labelId="demo-select-small"
                                    id="demo-select-small"
                                    value={product.subcategory}
                                />
                            </FormControl>
                        </Grid>
                        <Grid item lg={3} md={4} sm={6} xs={12}>
                            <InputLabel id="demo-select-small">Brand</InputLabel>
                            <FormControl size="small" fullWidth>
                                <OutlinedInput
                                    labelId="demo-select-small"
                                    id="demo-select-small"
                                    value={product.brand}
                                />
                            </FormControl>
                        </Grid>

                        {/* Grid three */}

                        <Grid item lg={3} md={4} sm={6} xs={12}>
                            <InputLabel id="demo-select-small">Purchase Excluding Tax</InputLabel>
                            <FormControl size="small" fullWidth>
                                <OutlinedInput
                                    id="component-outlined"
                                    value={product.purchaseexcludetax}
                                    type="text"
                                />
                            </FormControl>
                        </Grid>
                        <Grid item lg={3} md={4} sm={6} xs={12}>
                            <InputLabel id="demo-select-small">Purchase Including Tax</InputLabel>
                            <FormControl size="small" fullWidth>
                                <OutlinedInput
                                    id="component-outlined"
                                    value={product.pruchaseincludetax}
                                    type="text"
                                />
                            </FormControl>
                        </Grid>
                        <Grid item lg={3} md={4} sm={6} xs={12}>
                            <InputLabel id="demo-select-small">Selling Tax</InputLabel>
                            <FormControl size="small" fullWidth>
                                <OutlinedInput
                                    id="component-outlined"
                                    value={product.sellingexcludetax}
                                    type="text"
                                />
                            </FormControl>
                        </Grid>
                        <Grid item lg={3} md={4} sm={6} xs={12}>
                            <InputLabel id="demo-select-small" >Discount Type <b style={{ color: "red", marginLeft: "2px" }}>*</b></InputLabel>
                            <FormControl size="small" fullWidth>
                                <Select
                                    labelId="demo-select-small"
                                    id="demo-select-small"
                                    value={disAddForm.discounttype}
                                    onChange={(e) => {
                                        setDisAddForm({ ...disAddForm, discounttype: e.target.value }); 
                                    }}
                                >
                                    <MenuItem value="None" onClick={(e) => { getDiscount() }}>None</MenuItem>
                                    <MenuItem value="Fixed" onClick={(e) => { getDiscount() }}>Fixed</MenuItem>
                                    <MenuItem value="Amount" onClick={(e) => { getDiscount() }}>Amount</MenuItem>
                                    <MenuItem value="Percentage" onClick={(e) => { getDiscount() }}>Percentage</MenuItem>
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item lg={3} md={4} sm={6} xs={12}>
                            <InputLabel htmlFor="component-outlined">Select Discount Price</InputLabel>
                            <FormControl size="small" fullWidth>
                                <Select
                                    id="demo-select-small"
                                    value={disAddForm.selectdiscountprice}
                                    onChange={(e) => {
                                        setDisAddForm({ ...disAddForm, selectdiscountprice: e.target.value });

                                    }}
                                >
                                    <MenuItem value="Purchase Including Tax" onClick={(e) => { getDiscount() }}>Purchase Including Tax</MenuItem>
                                    <MenuItem value="Purchase Excluding Tax" onClick={(e) => { getDiscount() }}>Purchase Excluding Tax</MenuItem>
                                    <MenuItem value="Selling Tax" onClick={(e) => { getDiscount() }}>Selling Tax</MenuItem>
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item lg={3} md={4} sm={6} xs={12}>
                            <InputLabel htmlFor="component-outlined" >Discount Amount <b style={{ color: "red", marginLeft: "2px" }}>*</b></InputLabel>
                            <FormControl size="small" fullWidth>
                                <OutlinedInput
                                    id="component-outlined"
                                    value={disAddForm.discountamt}
                                    type="number"
                                    onChange={(e) => { setDisAddForm({ ...disAddForm, discountamt: e.target.value }); handleValidationAmount(e) }}
                                />
                            </FormControl>
                        </Grid>
                        {/* Grid four */}
                        <Grid item lg={3} md={4} sm={6} xs={12}>
                            <InputLabel htmlFor="component-outlined">Discount value</InputLabel>
                            <FormControl size="small" fullWidth>
                                <OutlinedInput
                                    id="component-outlined"
                                    type="number"
                                    value={disAddForm.discountvalue}
                                    onChange={(e) => { setDisAddForm({ ...disAddForm, discountvalue: e.target.value }); }}
                                />
                            </FormControl>
                        </Grid>
                        <Grid item lg={3} md={4} sm={6} xs={12}>
                            <InputLabel htmlFor="component-outlined">Start At</InputLabel>
                            <FormControl size="small" fullWidth>
                                <OutlinedInput
                                    id="component-outlined"
                                    value={disAddForm.startsat}
                                    onChange={(e) => { setDisAddForm({ ...disAddForm, startsat: e.target.value }) }}
                                    type="date"
                                />
                            </FormControl>
                        </Grid>
                        <Grid item lg={3} md={4} sm={6} xs={12}>
                            <InputLabel htmlFor="component-outlined">Ends At</InputLabel>
                            <FormControl size="small" fullWidth>
                                <OutlinedInput
                                    id="component-outlined"
                                    value={disAddForm.endsat}
                                    onChange={(e) => { setDisAddForm({ ...disAddForm, endsat: e.target.value }) }}
                                    type="date"
                                />
                            </FormControl>
                        </Grid>
                        <Grid container sx={userStyle.gridcontainer}>
                            <Grid >
                                <Button sx={userStyle.buttoncancel} onClick={handleBack}>CANCEL</Button>
                                <Button autoFocus sx={userStyle.buttonadd} type="submit" disableRipple>SAVE</Button>
                            </Grid>
                        </Grid>
                    </Grid>
                </form>
            </Box>
            {/* ALERT DIALOG */}
            <Box>
                <Dialog
                    open={isErrorOpen}
                    onClose={handleClose}
                    aria-labelledby="alert-dialog-title"
                    aria-describedby="alert-dialog-description"
                >
                    <DialogContent sx={{ width: '350px', textAlign: 'center', alignItems: 'center' }}>
                        <ErrorOutlineOutlinedIcon sx={{ fontSize: "80px", color: 'orange' }} />
                        <Typography variant="h6" >{showAlert}</Typography>
                    </DialogContent>
                    <DialogActions>
                        <Button variant="contained" color="error" onClick={handleClose}>ok</Button>
                    </DialogActions>
                </Dialog>
            </Box>
        </Box>
    );
}
function Discountcreates() {
    return (

        <>
            <Discountcreate /><br /><br /><br /><br />
                    <Footer />
        </>
    );
}

export default Discountcreates;