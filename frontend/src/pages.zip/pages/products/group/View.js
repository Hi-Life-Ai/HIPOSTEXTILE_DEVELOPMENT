import React, { useState, useContext, useEffect } from 'react';
import { Box, Button, Grid, FormControl, InputLabel, OutlinedInput, Typography, } from '@mui/material';
import { userStyle } from '../../PageStyle';
import Selects from "react-select";
import axios from 'axios';
import { useNavigate, Link, useParams } from 'react-router-dom';
import { toast } from 'react-toastify';
import Footer from '../../../components/footer/Footer';
import { SERVICE } from '../../../services/Baseservice';
import { AuthContext } from '../../../context/Appcontext';
import Headtitle from '../../../components/header/Headtitle';

function Groupviewpage() {

    const { auth } = useContext(AuthContext);
    const [addGroup, setAddGroup] = useState({});

    const id = useParams().id;

    const fetchGroupsingel = async () => {
        try {
            let res = await axios.get(`${SERVICE.GROUP_SINGLE}/${id}`, {
                headers: {
                    'Authorization': `Bearer ${auth.APIToken}`
                },
            });
            setAddGroup(res?.data?.sgroup)
        } catch (err) {
            const messages = err?.response?.data?.message;
            if (messages) {
                toast.error(messages);
            } else {
                toast.error("Something went wrong!")
            }
        }
    };
    useEffect(() => { fetchGroupsingel() }, [])



    return (
        <Box>
            <Headtitle title={'View Category Grouping'} />
            <Typography sx={userStyle.HeaderText}>View Category Grouping</Typography>
            {/* content start */}
            <Box sx={userStyle.container}>
                <form >
                    <Grid container spacing={3} sx={userStyle.textInput}>
                        <Grid item md={4} sm={12} xs={12}>
                            <InputLabel htmlFor="component-outlined">Brand Names</InputLabel>
                            <FormControl size="small" fullWidth>
                                <OutlinedInput
                                    id="component-outlined"
                                    readOnly
                                    value={addGroup.brandname}
                                />
                            </FormControl>
                        </Grid>
                        <Grid item md={4} sm={12} xs={12}>
                            <InputLabel htmlFor="component-outlined">Category Name</InputLabel>
                            <FormControl size="small" fullWidth>
                            <OutlinedInput
                                    id="component-outlined"
                                    readOnly
                                    value={addGroup?.categories?.map(d => d.categoryname).join(", ")}
                                />
                            </FormControl>
                        </Grid>
                    </Grid><br /><br />
                    <Grid container sx={userStyle.gridcontainer}>
                        <Grid sx={{ display: 'flex' }}>
                            <Link to="/product/group/list"><Button sx={userStyle.buttoncancel}>BACK</Button></Link>
                        </Grid>
                    </Grid>
                </form>
            </Box>
        </Box>
    );
}
function Groupview() {
    return (
       <>
        <Groupviewpage /><br /><br /><br /><br />
                    <Footer />
       </>
    );
}

export default Groupview;