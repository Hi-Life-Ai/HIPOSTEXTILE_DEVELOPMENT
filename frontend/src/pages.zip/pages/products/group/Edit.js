import React, { useState, useContext, useEffect } from 'react';
import { Box, Button, Grid, FormControl, InputLabel, Typography, Dialog, DialogActions, DialogContent} from '@mui/material';
import { userStyle } from '../../PageStyle';
import Selects , { components } from "react-select";
import axios from 'axios';
import { useNavigate, Link, useParams } from 'react-router-dom';
import ErrorOutlineOutlinedIcon from '@mui/icons-material/ErrorOutlineOutlined';
import { toast } from 'react-toastify';
import Footer from '../../../components/footer/Footer';
import { SERVICE } from '../../../services/Baseservice';
import { AuthContext } from '../../../context/Appcontext';
import Headtitle from '../../../components/header/Headtitle';

function GroupeditList() {

    const { auth, setngs } = useContext(AuthContext);

    const [categories, setCategories] = useState([]);
    const [brands, setBrand] = useState([]);
    const [addGroup, setAddGroup] = useState({
        brandname: "",
        brandshortname:""
    });
          //popup model
  const [isErrorOpen, setIsErrorOpen] = useState(false);
  const [showAlert, setShowAlert] = useState()
  const handleClickOpenc = () => { setIsErrorOpen(true); };
  const handleClose = () => { setIsErrorOpen(false); };
    const [selectedOptions, setSelectedOptions] = useState();
    let [values, setValue] = useState([])

    const InputOption = ({
        getStyles,
        Icon,
        isDisabled,
        isFocused,
        isSelected,
        children,
        innerProps,
        ...rest
      }) => {
        const [isActive, setIsActive] = useState(false);
        const onMouseDown = () => setIsActive(true);
        const onMouseUp = () => setIsActive(false);
        const onMouseLeave = () => setIsActive(false);
      
        // styles
        let bg = "transparent";
        if (isFocused) bg = "#eee";
        if (isActive) bg = "#B2D4FF";
      
        const style = {
          alignItems: "center",
          backgroundColor: bg,
          color: "inherit",
          display: "flex "
        };
      
        // prop assignment
        const props = {
          ...innerProps,
          onMouseDown,
          onMouseUp,
          onMouseLeave,
          style
        };
      
        return (
          <components.Option
            {...rest}
            isDisabled={isDisabled}
            isFocused={isFocused}
            isSelected={isSelected}
            getStyles={getStyles}
            innerProps={props}
          >
            <input type="checkbox" checked={isSelected} />
            {children}
          </components.Option>
        );
      };



    const handleChange = (options) => {
        setValue(options.map((a, index) => {
            return { ...a, categoryname: a.categoryname, categoryshotname:a.categoryshotname,subcategories: a.subcategories }
        }))
        setSelectedOptions(options);
    };
    const fetchBrands = async () => {
        try {
            let res = await axios.post(SERVICE.BRAND, {
                headers: {
                    'Authorization': `Bearer ${auth.APIToken}`
                },
                businessid: String(setngs.businessid)
            });
            const brandid = [{ label: 'Please Select Brand', value: 'Please Select Brand' },{ label: 'ALL', value: 'ALL' }, ...res?.data?.brands.map((d) => (
                {
                    ...d,
                    label: d.brandname,
                    value: d.brandname,
                }
            ))];
            setBrand(brandid)
        } catch (err) {
            const messages = err?.response?.data?.message;
            if (messages) {
                toast.error(messages);
            } else {
                toast.error("Something went wrong!")
            }
        }
    };


    const fetchCategory = async () => {
        try {
            let res = await axios.post(SERVICE.CATEGORIES, {
                headers: {
                    'Authorization': `Bearer ${auth.APIToken}`
                },
                businessid: String(setngs.businessid)
            });

            const catid = [{ label: 'Please Select Category', value: 'Please Select Category' },{ label: 'ALL', value: 'ALL' }, ...res?.data?.categories.map((d) => (
                {
                    ...d,
                    label: d.categoryname,
                    value: d.categoryname,
                }
            ))];
            setCategories(catid)
        } catch (err) {
            const messages = err?.response?.data?.message;
            if (messages) {
                toast.error(messages);
            } else {
                toast.error("Something went wrong!")
            }
        }
    };
    const backLPage = useNavigate();
    useEffect(() => { fetchCategory() }, [])

    const id = useParams().id;

    const fetchGroup = async () => {
        try {
            let res = await axios.put(`${SERVICE.GROUP_SINGLE}/${id}`, {
                headers: {
                    'Authorization': `Bearer ${auth.APIToken}`
                },
                assignbusinessid: String(setngs.businessid),
                brandname: String(addGroup.brandname),
                categories: [...values],
            });
            toast.success(res.data.message, {
                position: toast.POSITION.TOP_CENTER
            });
            backLPage('/product/group/list');
        } catch (err) {
            const messages = err?.response?.data?.message;
            if (messages) {
                toast.error(messages);
            } else {
                toast.error("Something went wrong!")
            }
        }
    };
    const fetchGroupsingel = async () => {
        try {
            let res = await axios.get(`${SERVICE.GROUP_SINGLE}/${id}`, {
                headers: {
                    'Authorization': `Bearer ${auth.APIToken}`
                },
                assignbusinessid: String(setngs.businessid),
            });

            setAddGroup(res?.data?.sgroup)
            setSelectedOptions(res?.data?.sgroup.categories.map(e => ({ value: e.categoryname, label: e.categoryname })))
            setValue(res?.data?.sgroup?.categories)
        } catch (err) {
            const messages = err?.response?.data?.message;
            if (messages) {
                toast.error(messages);
            } else {
                toast.error("Something went wrong!")
            }
        }
    };
    useEffect(() => { 
        fetchGroupsingel();
        fetchBrands(); 
    }, [])

    const handleSubmit = (e) => {
        e.preventDefault();
        if(addGroup.brandname == ""){
            setShowAlert("Please Select Brand!");
            handleClickOpenc();
        }else if(values.length == "" || 0){
            setShowAlert("Please Select Category!");
            handleClickOpenc();
        }else{
            fetchGroup();
        }
    }
    return (
        <Box>
            <Headtitle title={'Edit Category Grouping'} />
            <Typography sx={userStyle.HeaderText}>Edit Category Grouping</Typography>
            {/* content start */}
            <Box sx={userStyle.container}>
                <form onSubmit={handleSubmit}>
                    <Grid container spacing={3} sx={userStyle.textInput}>
                        <Grid item md={4} sm={12} xs={12}>
                            <InputLabel htmlFor="component-outlined">Brand Names</InputLabel>
                            <FormControl size="small" fullWidth>
                                <Selects
                                    id="component-outlined"
                                    options={brands}
                                    value={{ label: addGroup.brandname, value: addGroup.brandname }}
                                    onChange={(e) => { setAddGroup({ ...addGroup, brandname: e.value, brandshortname:e.brandshortname }) }}
                                    name="brandname"
                                    placeholder='Brand Name'
                                  
                                />
                            </FormControl>
                        </Grid>
                        <Grid item md={4} sm={12} xs={12}>
                            <InputLabel htmlFor="component-outlined">Category Name</InputLabel>
                            <FormControl size="small" fullWidth>
                                <Selects
                                    id="component-outlined"
                                    options={categories}
                                    isMulti
                                    value={selectedOptions}
                                    onChange={(e) => { handleChange(e); }}
                                    name="Category Name"
                                    placeholder="Category Name"
                                    closeMenuOnSelect={false}
                                    hideSelectedOptions={false}
                                    components={{
                                        Option: InputOption
                                      }}
                                />
                            </FormControl>
                        </Grid>
                    </Grid><br /><br />
                    <Grid container sx={userStyle.gridcontainer}>
                        <Grid sx={{ display: 'flex' }}>
                            <Button sx={userStyle.buttonadd} type="submit" >Update</Button>
                            <Link to="/product/group/list"><Button sx={userStyle.buttoncancel}>cancel</Button></Link>
                        </Grid>
                    </Grid>
                </form>
            </Box>
            {/* ALERT DIALOG */}
      <Box>
        <Dialog
          open={isErrorOpen}
          onClose={handleClose}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogContent sx={{ width: '350px', textAlign: 'center', alignItems: 'center' }}>
            <ErrorOutlineOutlinedIcon sx={{ fontSize: "80px", color: 'orange' }} />
            <Typography variant="h6" >{showAlert}</Typography>
          </DialogContent>
          <DialogActions>
            <Button variant="contained" color="error" onClick={handleClose}>ok</Button>
          </DialogActions>
        </Dialog>
      </Box>
        </Box>
    );
}
function Groupedit() {
    return (
       <>
         <GroupeditList /><br /><br /><br /><br />
                    <Footer />
       </>
    );
}

export default Groupedit;