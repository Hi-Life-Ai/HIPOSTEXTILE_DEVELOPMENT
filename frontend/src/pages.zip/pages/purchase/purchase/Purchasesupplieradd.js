import React, { useState, useEffect, useContext } from 'react';
import { Button, Typography, Grid, InputLabel, FormControl, Box, OutlinedInput, FormControlLabel, Checkbox, TextareaAutosize, Dialog, DialogTitle, DialogContent, DialogActions } from '@mui/material';
import ContactPageOutlinedIcon from '@mui/icons-material/ContactPageOutlined';
import PersonOutlineOutlinedIcon from '@mui/icons-material/PersonOutlineOutlined';
import EmailIconOutlined from '@mui/icons-material/EmailOutlined';
import LocationOnIconOutlined from '@mui/icons-material/LocationOnOutlined';
import LanguageOutlinedIcon from '@mui/icons-material/LanguageOutlined';
import { userStyle, colourStyles } from '../../PageStyle';
import axios from 'axios';
import { toast } from 'react-toastify';
import { Country, State, City } from "country-state-city";
import AddCircleOutlineOutlinedIcon from '@mui/icons-material/AddCircleOutlineOutlined';
import ErrorOutlineOutlinedIcon from '@mui/icons-material/ErrorOutlineOutlined';
import Select from 'react-select';
import { SERVICE } from "../../../services/Baseservice";
import { AuthContext } from '../../../context/Appcontext';

function Purchasesupplieradd({ setIsSupplierFetch }) {

    const { auth, setngs } = useContext(AuthContext);
    const [suppliers, setSuppliers] = useState([]);

    //  Add Text Field
    const [supplier, setSupplier] = useState({
        autogenerate: "", suppliername: "", suppshortname: "", addressone: "", addresstwo: "", country: "", state: "",
        city: "", pincode: "", supplieremail: "", gstn: "", phoneone: "", phonetwo: "", phonethree: "", phonecheck: false,
        phonefour: "", landline: "", whatsapp: "", contactperson: "", creditdays: "",
    });

    //  Modal
    const [purchaseMod, setPurchaseMod] = useState(false);
    const purchaseModOpen = () => { setPurchaseMod(true); };
    const purchaseModClose = () => {
        fetchSuppliers();
        setSupplier({
            autogenerate: "", suppliername: "", suppshortname: "", addressone: "", addresstwo: "", country: "", state: "",
            city: "", pincode: "", supplieremail: "", gstn: "", phoneone: "", phonetwo: "", phonethree: "", phonecheck: false,
            phonefour: "", landline: "", whatsapp: "", contactperson: "", creditdays: "",
        });
        setPurchaseMod(false);
    };

    const [selectedCountry, setSelectedCountry] = useState(Country.getAllCountries().find(country => country.name === "India"));
    const [selectedState, setSelectedState] = useState(State.getStatesOfCountry(selectedCountry?.isoCode).find(state => state.name === "Tamil Nadu"));
    const [selectedCity, setSelectedCity] = useState(City.getCitiesOfState(selectedState?.countryCode, selectedState?.isoCode).find(city => city.name === "Tiruchirappalli"));

    // Popup model
    const [isErrorOpen, setIsErrorOpen] = useState(false);
    const [showAlert, setShowAlert] = useState()
    const handleClickOpen = () => { setIsErrorOpen(true); };
    const handleClose = () => { setIsErrorOpen(false); };

    // auto id for purchase number
    let newval = setngs ? setngs.suppliersku == undefined ? "SR0001" : setngs.suppliersku + "0001" : "SR0001";

    // Phone Number length
    const handlePincode = (e) => {
        if (e.length > 6) {
            setShowAlert("Pin code can't more than 6 characters!")
            handleClickOpen();
            let num = e.slice(0, 6);
            setSupplier({ ...supplier, pincode: num })
        }
    }
    const handlePhoneone = (e) => {
        if (e.length > 10) {
            setShowAlert("Phone number can't more than 10 characters!")
            handleClickOpen();
            let num = e.slice(0, 10);
            setSupplier({ ...supplier, phoneone: num })
        }
    }
    const handlePhonetwo = (e) => {
        if (e.length > 10) {
            setShowAlert("Phone number can't more than 10 characters!")
            handleClickOpen();
            let num = e.slice(0, 10);
            setSupplier({ ...supplier, phonetwo: num })
        }
    }
    const handlePhonethree = (e) => {
        if (e.length > 10) {
            setShowAlert("Phone number can't more than 10 characters!")
            handleClickOpen();
            let num = e.slice(0, 10);
            setSupplier({ ...supplier, phonethree: num })
        }
    }
    const handlePhonefour = (e) => {
        if (e.length > 10) {
            setShowAlert("Phone number can't more than 10 characters!")
            handleClickOpen();
            let num = e.slice(0, 10);
            setSupplier({ ...supplier, phonefour: num })
        }
    }
    const handleWhatsapp = (e) => {
        if (e.length > 10) {
            setShowAlert("Whatsapp number can't more than 10 characters!")
            handleClickOpen();
            let num = e.slice(0, 10);
            setSupplier({ ...supplier, whatsapp: num })
        }
    }
    const handleGstn = (e) => {
        if (e.length > 15) {
            setShowAlert("Phone number can't more than 15 characters!")
            handleClickOpen();
            let num = e.slice(0, 15);
            setSupplier({ ...supplier, gstn: num })
        }
    }

    const getPhoneNumber = async (value, e) => {
        if (value !== false) {
            setSupplier({ ...supplier, whatsapp: supplier.phoneone })
        } else (
            setSupplier({ ...supplier, whatsapp: e.target.value })
        )
    }

    const handleShortname = (e) => {
        let data = e.replace(/[^a-zA-Z0-9]/g, '');
        if (data.length > 4) {
            setShowAlert("ShortName can't more than 4 characters!")
            handleClickOpen();
            let num = data.slice(0, 4);
            setSupplier({ ...supplier, suppshortname: num.toUpperCase() })
        }
    }


    const handleValidationLandline = (e) => {
        let val = e.target.value;
        let numbers = new RegExp('[a-z]');
        var regex = /[`!@#$%^&*()_+\=\[\]{};':"\\|,.<>\/?~]/;
        if (e.target.value.match(numbers)) {
            setShowAlert("Please enter number only! (0-9)")
            handleClickOpen();
            let num = val.length;
            let value = val.slice(0, num - 1)
            setSupplier({ ...supplier, landline: value })
        }
        else if (regex.test(e.target.value)) {
            setShowAlert("Please enter number only! (0-9)")
            handleClickOpen();
            let num = val.length;
            let value = val.slice(0, num - 1)
            setSupplier({ ...supplier, landline: value })
        }
    }

    const handleSup = (e) => {
        let codeslicespace = e.replace(/[^a-zA-Z0-9]/g, '');
        let resultshotname = codeslicespace.slice(0, 4).toUpperCase();

        setSupplier({ ...supplier, suppliername: e, suppshortname: resultshotname });

    }

    // Suppliers
    const fetchSuppliers = async () => {
        try {
            let res = await axios.post(SERVICE.SUPPLIER, {
                headers: {
                    'Authorization': `Bearer ${auth.APIToken}`
                },
                businessid: String(setngs.businessid)
            });
            setSuppliers(res?.data?.suppliers);
        } catch (err) {
            const messages = err?.response?.data?.message;
            if (messages) {
                toast.error(messages);
            } else {
                toast.error("Something went wrong!")
            }
        }
    };

    useEffect(() => {
        fetchSuppliers();
    }, [])

    const addSupplier = async () => {
        let codeslicespace = supplier.suppliername.replace(/[^a-zA-Z0-9]/g, '');
        let resultshotname = codeslicespace.slice(0, 4).toUpperCase();
        try {
            let req = await axios.post(SERVICE.SUPPLIER_CREATE, {
                headers: {
                    'Authorization': `Bearer ${auth.APIToken}`
                },
                autogenerate: String(newval),
                suppliername: String(supplier.suppliername),
                addressone: String(supplier.addressone),
                addresstwo: String(supplier.addresstwo),
                country: String(selectedCountry.name ? selectedCountry.name : ""),
                state: String(selectedState.name ? selectedState.name : ""),
                city: String(selectedCity.name ? selectedCity.name : ""),
                pincode: Number(supplier.pincode),
                supplieremail: String(supplier.supplieremail),
                gstn: String(supplier.gstn),
                phoneone: Number(supplier.phoneone),
                phonetwo: Number(supplier.phonetwo),
                phonethree: Number(supplier.phonethree),
                phonefour: Number(supplier.phonefour),
                landline: String(supplier.landline),
                whatsapp: Number(supplier.whatsapp),
                contactperson: String(supplier.contactperson),
                creditdays: Number(supplier.creditdays),
                phonecheck: Boolean(supplier.phonecheck),
                suppshortname: String(supplier.suppshortname == "" || supplier.suppshortname == undefined ? resultshotname : supplier.suppshortname),
                assignbusinessid: String(setngs.businessid),

            });
            setIsSupplierFetch('None');
            purchaseModClose();
            toast.success(req.data.message, {
                position: toast.POSITION.TOP_CENTER
            });
            setSupplier({
                autogenerate: "", suppliername: "", suppshortname: "", addressone: "", addresstwo: "", country: "", state: "",
                city: "", pincode: "", supplieremail: "", gstn: "", phoneone: "", phonetwo: "", phonethree: "", phonecheck: false,
                phonefour: "", landline: "", whatsapp: "", contactperson: "", creditdays: "",
            })
            await fetchSuppliers();
        }
        catch (err) {
            const messages = err?.response?.data?.message;
            if (messages) {
                setShowAlert(messages);
                handleClickOpen();
            } else {
                setShowAlert("Something went wrong!");
                handleClickOpen();
            }
        }
    }

    const handleSubmit = (e) => {
        e.preventDefault();
        const isNameMatch = suppliers.some(item => item.suppliername.toLowerCase() === (supplier.suppliername).toLowerCase());
        const isCodeMatch = suppliers.some(item => item.autogenerate.toLowerCase() === (newval).toLowerCase());

        if (isCodeMatch) {
            setShowAlert("ID Already Exists");
            handleClickOpen();
        }
        else if (isNameMatch) {
            setShowAlert("Supplier Name Already Exists");
            handleClickOpen();
        }
        else if (supplier.suppliername == "") {
            setShowAlert("Please enter supplier name!")
            handleClickOpen();
        } else if (supplier.gstn != "" && supplier.gstn.length != 15) {
            setShowAlert("Please enter GSTN No can't more than 15 characters!")
            handleClickOpen();
        }
        else if (supplier.phoneone == "") {
            setShowAlert("Please enter Phone No!")
            handleClickOpen();
        } else if (supplier.phoneone.length != 10) {
            setShowAlert("Please enter Phone No can't more than 10 characters!")
            handleClickOpen();
        }
        else if (supplier.phonetwo != "" && supplier.phonetwo.length != 10) {
            setShowAlert("Please enter Phone No can't more than 10 characters!")
            handleClickOpen();
        }
        else if (supplier.phonethree != "" && supplier.phonethree.length != 10) {
            setShowAlert("Please enter Phone No can't more than 10 characters!")
            handleClickOpen();
        }
        else if (supplier.phonefour != "" && supplier.phonefour.length != 10) {
            setShowAlert("Please enter Phone No can't more than 10 characters!")
            handleClickOpen();
        } else if (supplier.whatsapp.length != 10) {
            setShowAlert("Please enter Whatsapp No can't more than 10 characters!")
            handleClickOpen();
        }
        else {
            addSupplier();
        }
    }

    return (
        <Box >
            <Box>
                <AddCircleOutlineOutlinedIcon onClick={purchaseModOpen} />
                <Dialog PaperProps={{ style: { borderRadius: "10px" } }}
                    onClose={purchaseModClose}
                    open={purchaseMod}
                    keepMounted
                    sx={{
                        '& .MuiOutlinedInput-notchedOutline': {
                            border: '1px solid #b97df0',
                        },
                    }}
                    maxWidth="lg"
                    aria-describedby="alert-dialog-slide-description"
                >
                    <DialogTitle id="customized-dialog-title1" onClose={purchaseModClose} sx={{ backgroundColor: '#e0e0e0', color: "#000", display: "flex" }}>
                        Add Supplier
                    </DialogTitle>
                    <DialogContent dividers sx={{
                        minWidth: '800px', height: 'auto', '& .MuiOutlinedInput-notchedOutline': {
                            border: '1px solid #4a7bf7 !important',
                        },
                    }}>
                        <Grid container spacing={3}>
                            <Grid item md={2} sm={3} xs={12}>
                                <Typography variant='h6' sx={{ justifyContent: 'center' }}>S.No</Typography>
                            </Grid>
                            <Grid item md={2} sm={3} xs={12}>
                                <Typography variant='h6'>Fields</Typography>
                            </Grid>
                            <Grid item md={8} sm={6} xs={12}></Grid>
                            <Grid item md={2} sm={3} xs={12}><Typography variant='h6' sx={{ marginLeft: '50px' }}>1.</Typography></Grid>
                            <Grid item md={2} sm={3} xs={12}>
                                <Typography variant='h6'>Supplier Code</Typography>
                            </Grid>
                            <Grid item md={6} sm={6} xs={12}>
                                <InputLabel htmlFor="component-outlined">Auto Generate</InputLabel>
                                {suppliers && (
                                    suppliers.map(
                                        () => {
                                            let strings = setngs ? setngs.suppliersku : "SR";
                                            let refNo = suppliers[suppliers.length - 1].autogenerate;
                                            let digits = (suppliers.length + 1).toString();
                                            const stringLength = refNo.length;
                                            let lastChar = refNo.charAt(stringLength - 1);
                                            let getlastBeforeChar = refNo.charAt(stringLength - 2);
                                            let getlastThreeChar = refNo.charAt(stringLength - 3);
                                            let lastBeforeChar = refNo.slice(-2);
                                            let lastThreeChar = refNo.slice(-3);
                                            let lastDigit = refNo.slice(-4);
                                            let refNOINC = parseInt(lastChar) + 1
                                            let refLstTwo = parseInt(lastBeforeChar) + 1;
                                            let refLstThree = parseInt(lastThreeChar) + 1;
                                            let refLstDigit = parseInt(lastDigit) + 1;
                                            if (digits.length < 4 && getlastBeforeChar == 0 && getlastThreeChar == 0) {
                                                refNOINC = ("000" + refNOINC);
                                                newval = strings + refNOINC;
                                            } else if (digits.length < 4 && getlastBeforeChar > 0 && getlastThreeChar == 0) {
                                                refNOINC = ("00" + refLstTwo);
                                                newval = strings + refNOINC;
                                            } else if (digits.length < 4 && getlastThreeChar > 0) {
                                                refNOINC = ("0" + refLstThree);
                                                newval = strings + refNOINC;
                                            } else {
                                                refNOINC = (refLstDigit);
                                                newval = strings + refNOINC;
                                            }
                                        }))}
                                <Grid sx={{ display: 'flex' }}  >
                                    <Grid sx={userStyle.spanIcons}><ContactPageOutlinedIcon /></Grid>
                                    <FormControl size="small" fullWidth>
                                        <OutlinedInput
                                            sx={userStyle.alertOutline}
                                            id="component-outlined"
                                            value={newval}
                                            type="text"
                                            name="autogenerate"
                                            readOnly
                                        />
                                    </FormControl>
                                </Grid>
                            </Grid>
                            <Grid item md={2} xs={12}></Grid>
                            <Grid item md={2} sm={3} xs={12}><Typography variant='h6' sx={{ marginLeft: '50px' }}>2.</Typography></Grid>
                            <Grid item md={2} sm={3} xs={12}>
                                <Typography variant='h6' sx={{ display: "flex" }}>Supplier Name <Typography style={{ color: "red" }}>*</Typography></Typography>
                            </Grid>
                            <Grid item md={3} sm={3} xs={12}>
                                <Grid sx={{ display: 'flex' }}  >
                                    <Grid sx={userStyle.spanIcons}><PersonOutlineOutlinedIcon /></Grid>
                                    <FormControl size="small" fullWidth>
                                        <OutlinedInput
                                            id="component-outlined"
                                            sx={userStyle.alertOutline}
                                            value={supplier.suppliername}
                                            onChange={(e) => { handleSup(e.target.value); }}
                                            type="text"
                                        />
                                    </FormControl>
                                </Grid>
                            </Grid>
                            <Grid item md={3} sm={3} xs={12}>
                                <FormControl size="small" fullWidth>
                                    <InputLabel>Supplier Shortname</InputLabel>
                                    <OutlinedInput
                                        id="component-outlined"
                                        value={supplier.suppshortname}
                                        onChange={(e) => { setSupplier({ ...supplier, suppshortname: e.target.value.replace(/[^a-zA-Z0-9]/g, '').toUpperCase() }); handleShortname(e.target.value) }}
                                        type="text"
                                        name="suppliershortname"
                                        label="suppliershortname"
                                    />
                                </FormControl>
                            </Grid>
                            <Grid item md={2} xs={12}></Grid>
                            <Grid item md={2} sm={3} xs={12}><Typography variant='h6' sx={{ marginLeft: '50px' }}>3.</Typography></Grid>
                            <Grid item md={2} sm={3} xs={12}>
                                <Typography variant='h6'>Address1</Typography>
                            </Grid>
                            <Grid item md={6} sm={6} xs={12}>
                                <FormControl size="small" fullWidth >
                                    <TextareaAutosize aria-label="minimum height" minRows={3} style={{ border: '1px solid #4a7bf7' }}
                                        value={supplier.addressone}
                                        onChange={(e) => { setSupplier({ ...supplier, addressone: e.target.value }) }}
                                    />
                                </FormControl>
                            </Grid>
                            <Grid item md={2} xs={12}></Grid>
                            <Grid item md={2} sm={3} xs={12}><Typography variant='h6' sx={{ marginLeft: '50px' }}>4.</Typography></Grid>
                            <Grid item md={2} sm={3} xs={12}>
                                <Typography variant='h6'>Address2</Typography>
                            </Grid>
                            <Grid item md={6} sm={6} xs={12}>
                                <FormControl size="small" fullWidth >
                                    <TextareaAutosize aria-label="minimum height" minRows={3} style={{ border: '1px solid #4a7bf7' }}
                                        value={supplier.addresstwo}
                                        onChange={(e) => { setSupplier({ ...supplier, addresstwo: e.target.value }) }}
                                    />
                                </FormControl>
                            </Grid>
                            <Grid item md={2} xs={12}></Grid>
                            <Grid item md={2} sm={3} xs={12}><Typography variant='h6' sx={{ marginLeft: '50px' }}>5.</Typography></Grid>
                            <Grid item md={2} sm={3} xs={12}>
                                <Typography variant='h6'>Country</Typography>
                            </Grid>
                            <Grid item md={6} sm={6} xs={12}>
                                <Grid sx={{ display: 'flex' }}>
                                    <Grid sx={userStyle.spanIcons}><LanguageOutlinedIcon /></Grid>
                                    <FormControl size="small" fullWidth>
                                        <Select
                                            options={Country.getAllCountries()}
                                            getOptionLabel={(options) => {
                                                return options["name"];
                                            }}
                                            getOptionValue={(options) => {
                                                return options["name"];
                                            }}
                                            value={selectedCountry}
                                            styles={colourStyles}
                                            onChange={(item) => {
                                                setSelectedCountry(item);
                                            }}
                                        />
                                    </FormControl>
                                </Grid>
                            </Grid>
                            <Grid item md={2} xs={12}></Grid>
                            <Grid item md={2} sm={3} xs={12}><Typography variant='h6' sx={{ marginLeft: '50px' }}>6.</Typography></Grid>
                            <Grid item md={2} sm={3} xs={12}>
                                <Typography variant='h6'>State</Typography>
                            </Grid>
                            <Grid item md={6} sm={6} xs={12}>
                                <Grid sx={{ display: 'flex' }}>
                                    <Grid sx={userStyle.spanIcons}><LocationOnIconOutlined /></Grid>
                                    <FormControl size="small" fullWidth>
                                        <Select
                                            options={State?.getStatesOfCountry(selectedCountry?.isoCode)}
                                            getOptionLabel={(options) => {
                                                return options["name"];
                                            }}
                                            getOptionValue={(options) => {
                                                return options["name"];
                                            }}
                                            value={selectedState}
                                            styles={colourStyles}
                                            onChange={(item) => {
                                                setSelectedState(item);
                                            }}
                                        />
                                    </FormControl>
                                </Grid>
                            </Grid>
                            <Grid item md={2} xs={12}></Grid>
                            <Grid item md={2} sm={3} xs={12}><Typography variant='h6' sx={{ marginLeft: '50px' }}>7.</Typography></Grid>
                            <Grid item md={2} sm={3} xs={12}>
                                <Typography variant='h6'>City</Typography>
                            </Grid>
                            <Grid item md={6} sm={6} xs={12}>
                                <Grid sx={{ display: 'flex' }}  >
                                    <Grid sx={userStyle.spanIcons}><LocationOnIconOutlined /></Grid>
                                    <FormControl size="small" fullWidth>
                                        <Select
                                            options={City.getCitiesOfState(
                                                selectedState?.countryCode,
                                                selectedState?.isoCode
                                            )}
                                            getOptionLabel={(options) => {
                                                return options["name"];
                                            }}
                                            getOptionValue={(options) => {
                                                return options["name"];
                                            }}
                                            value={selectedCity}
                                            styles={colourStyles}
                                            onChange={(item) => {
                                                setSelectedCity(item);
                                            }}
                                        />
                                    </FormControl>
                                </Grid>
                            </Grid>
                            <Grid item md={2} xs={12}></Grid>
                            <Grid item md={2} sm={3} xs={12}><Typography variant='h6' sx={{ marginLeft: '50px' }}>8.</Typography></Grid>
                            <Grid item md={2} sm={3} xs={12}>
                                <Typography variant='h6'>Pincode</Typography>
                            </Grid>
                            <Grid item md={6} sm={6} xs={12}>
                                <Grid sx={{ display: 'flex' }}  >
                                    <Grid sx={userStyle.spanIcons}><LocationOnIconOutlined /></Grid>
                                    <FormControl size="small" fullWidth>
                                        <OutlinedInput
                                            sx={[userStyle.alertOutline, userStyle.input]}
                                            id="component-outlined"
                                            value={supplier.pincode}
                                            onChange={(e) => { setSupplier({ ...supplier, pincode: e.target.value }); handlePincode(e.target.value) }}
                                            type="number"
                                        />
                                    </FormControl>
                                </Grid>
                            </Grid>
                            <Grid item md={2} xs={12}></Grid>
                            <Grid item md={2} sm={3} xs={12}><Typography variant='h6' sx={{ marginLeft: '50px' }}>9.</Typography></Grid>
                            <Grid item md={2} sm={3} xs={12}>
                                <Typography variant='h6'>Email</Typography>
                            </Grid>
                            <Grid item md={6} sm={6} xs={12}>
                                <Grid sx={{ display: 'flex' }}  >
                                    <Grid sx={userStyle.spanIcons}><EmailIconOutlined /></Grid>
                                    <FormControl size="small" fullWidth>
                                        <OutlinedInput
                                            sx={userStyle.alertOutline}
                                            id="component-outlined"
                                            value={supplier.supplieremail}
                                            onChange={(e) => { setSupplier({ ...supplier, supplieremail: e.target.value }) }}
                                            type="email"
                                        />
                                    </FormControl>
                                </Grid>
                            </Grid>
                            <Grid item md={2} xs={12}></Grid>
                            <Grid item md={2} sm={3} xs={12}><Typography variant='h6' sx={{ marginLeft: '50px' }}>10.</Typography></Grid>
                            <Grid item md={2} sm={3} xs={12}>
                                <Typography variant='h6'>GSTN</Typography>
                            </Grid>
                            <Grid item md={6} sm={6} xs={12}>
                                <FormControl size="small" fullWidth>
                                    <OutlinedInput
                                        sx={userStyle.alertOutline}
                                        id="component-outlined"
                                        value={supplier.gstn}
                                        onChange={(e) => { setSupplier({ ...supplier, gstn: e.target.value }); handleGstn(e.target.value) }}
                                        type="text"
                                    />
                                </FormControl>
                            </Grid>
                            <Grid item md={2} xs={12}></Grid>
                            <Grid item md={2} sm={3} xs={12}><Typography variant='h6' sx={{ marginLeft: '50px' }}>11.</Typography></Grid>
                            <Grid item md={2} sm={3} xs={12}>
                                <Typography variant='h6' sx={{ display: "flex" }}>Phone <Typography style={{ color: "red" }}>*</Typography></Typography>
                            </Grid>
                            <Grid item md={6} sm={6} xs={12}>
                                <Grid container spacing={1}>
                                    <Grid item md={6} sm={6} xs={12} >
                                        <InputLabel htmlFor="component-outlined">Phone1</InputLabel>
                                        <FormControl size="small" fullWidth>
                                            <OutlinedInput
                                                sx={[userStyle.alertOutline, userStyle.input]}
                                                id="component-outlined"
                                                value={supplier.phoneone}
                                                onChange={(e) => { setSupplier({ ...supplier, phoneone: e.target.value }); handlePhoneone(e.target.value) }}
                                                type="number"
                                            />
                                        </FormControl>
                                        <Grid>
                                            <FormControlLabel control={<Checkbox
                                                value={supplier.phonecheck}
                                                onChange={(e) => {
                                                    setSupplier({ ...supplier, phonecheck: e.target.value }); handleWhatsapp(e.target.value); getPhoneNumber(e.target.value)
                                                }}
                                            />} label="Same as whatsapp no" />
                                        </Grid>
                                    </Grid>
                                    <Grid item md={6} sm={6} xs={12}>
                                        <InputLabel htmlFor="component-outlined">Phone2</InputLabel>
                                        <FormControl size="small" fullWidth>
                                            <OutlinedInput
                                                sx={[userStyle.alertOutline, userStyle.input]}
                                                id="component-outlined"
                                                value={supplier.phonetwo}
                                                onChange={(e) => { setSupplier({ ...supplier, phonetwo: e.target.value }); handlePhonetwo(e.target.value); }}
                                                type="number"
                                            />
                                        </FormControl>
                                    </Grid>
                                    <Grid item md={6} sm={6} xs={12}>
                                        <InputLabel htmlFor="component-outlined">Phone3</InputLabel>
                                        <FormControl size="small" fullWidth>
                                            <OutlinedInput
                                                sx={[userStyle.alertOutline, userStyle.input]}
                                                id="component-outlined"
                                                value={supplier.phonethree}
                                                onChange={(e) => { setSupplier({ ...supplier, phonethree: e.target.value }); handlePhonethree(e.target.value); }}
                                                type="number"
                                            />
                                        </FormControl>
                                    </Grid>
                                    <Grid item md={6} sm={6} xs={12}>
                                        <InputLabel htmlFor="component-outlined">Phone4</InputLabel>
                                        <FormControl size="small" fullWidth>
                                            <OutlinedInput
                                                sx={[userStyle.alertOutline, userStyle.input]}
                                                id="component-outlined"
                                                value={supplier.phonefour}
                                                onChange={(e) => { setSupplier({ ...supplier, phonefour: e.target.value }); handlePhonefour(e.target.value); }}
                                                type="number"
                                            />
                                        </FormControl>
                                    </Grid>
                                </Grid>
                            </Grid>
                            <Grid item md={2} xs={12}></Grid>
                            <Grid item md={2} sm={3} xs={12}><Typography variant='h6' sx={{ marginLeft: '50px' }}>12.</Typography></Grid>
                            <Grid item md={2} sm={3} xs={12}>
                                <Typography variant='h6'>Landline</Typography>
                            </Grid>
                            <Grid item md={6} sm={6} xs={12}>
                                <FormControl size="small" fullWidth>
                                    <OutlinedInput
                                        sx={[userStyle.alertOutline, userStyle.input]}
                                        id="component-outlined"
                                        value={supplier.landline}
                                        onChange={(e) => { setSupplier({ ...supplier, landline: e.target.value }); handleValidationLandline(e) }}
                                        type="text"
                                    />
                                </FormControl>
                            </Grid>
                            <Grid item md={2} xs={12}></Grid>
                            <Grid item md={2} sm={3} xs={12}><Typography variant='h6' sx={{ marginLeft: '50px' }}>13.</Typography></Grid>
                            <Grid item md={2} sm={3} xs={12}>
                                <Typography variant='h6' sx={{ display: "flex" }}>Whatsapp <Typography style={{ color: "red" }}>*</Typography></Typography>
                            </Grid>
                            <Grid item md={6} sm={6} xs={12}>
                                <FormControl size="small" fullWidth>
                                    <OutlinedInput
                                        sx={[userStyle.alertOutline, userStyle.input]}
                                        id="component-outlined"
                                        value={supplier.whatsapp}
                                        onChange={(e) => { setSupplier({ ...supplier, whatsapp: e.target.value }); handleWhatsapp(e.target.value) }}
                                        type="number"
                                    />
                                </FormControl>
                            </Grid>
                            <Grid item md={2} xs={12}></Grid>
                            <Grid item md={2} sm={3} xs={12}><Typography variant='h6' sx={{ marginLeft: '50px' }}>14.</Typography></Grid>
                            <Grid item md={2} sm={3} xs={12}>
                                <Typography variant='h6'>Contact Person</Typography>
                            </Grid>
                            <Grid item md={6} sm={6} xs={12}>
                                <FormControl size="small" fullWidth>
                                    <OutlinedInput
                                        sx={userStyle.alertOutline}
                                        id="component-outlined"
                                        value={supplier.contactperson}
                                        onChange={(e) => { setSupplier({ ...supplier, contactperson: e.target.value }) }}
                                        type="text"
                                    />
                                </FormControl>
                            </Grid>
                            <Grid item md={2} xs={12}></Grid>
                            <Grid item md={2} sm={3} xs={12}><Typography variant='h6' sx={{ marginLeft: '50px' }}>15.</Typography></Grid>
                            <Grid item md={2} sm={3} xs={12}>
                                <Typography variant='h6'>Credit Days</Typography>
                            </Grid>
                            <Grid item md={6} sm={6} xs={12}>
                                <FormControl size="small" fullWidth>
                                    <OutlinedInput
                                        sx={[userStyle.alertOutline, userStyle.input]}
                                        id="component-outlined"
                                        value={supplier.creditdays}
                                        onChange={(e) => { setSupplier({ ...supplier, creditdays: e.target.value }) }}
                                        type="number"
                                    />
                                </FormControl>
                            </Grid>
                            <Grid item md={2} xs={12}></Grid>
                        </Grid>
                    </DialogContent>
                    <DialogActions>
                        <Button sx={userStyle.buttonadd} type="submit" onClick={handleSubmit} disableRipple>SAVE</Button>
                        <Button sx={userStyle.buttoncancel} autoFocus onClick={purchaseModClose} disableRipple>CLOSE</Button>
                    </DialogActions>
                </Dialog>

                <>
                    {/* ALERT DIALOG */}
                    <Box>
                        <Dialog
                            open={isErrorOpen}
                            onClose={handleClose}
                            aria-labelledby="alert-dialog-title"
                            aria-describedby="alert-dialog-description"
                        >
                            <DialogContent sx={{ width: '350px', textAlign: 'center', alignItems: 'center' }}>
                                <ErrorOutlineOutlinedIcon sx={{ fontSize: "80px", color: 'orange' }} />
                                <Typography variant="h6" >{showAlert}</Typography>
                            </DialogContent>
                            <DialogActions>
                                <Button variant="contained" color="error" onClick={handleClose}>ok</Button>
                            </DialogActions>
                        </Dialog>
                    </Box>
                </>
            </Box>
        </Box>
    );
}

export default Purchasesupplieradd;