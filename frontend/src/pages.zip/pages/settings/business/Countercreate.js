import React, { useState, useContext } from 'react';
import { Box, Grid, FormControl, InputLabel, OutlinedInput, Button } from '@mui/material';
import { userStyle } from '../../PageStyle';
import { FaPlus } from 'react-icons/fa';
import { AiOutlineClose } from 'react-icons/ai';

export default function Countercreate({ counters, setCounters }) {

  const [subStringVal, setSubStringVal] = useState("0001");
  function addCounter() {
    let counterstart = counters[counters.length - 1].counterid == undefined || "" ? parseInt("0001") : counters[counters.length - 1].counterid
    let codenum = counterstart.slice(2);
    let prefixLength = Number(codenum) + 1;
    let prefixString = String(prefixLength);
    let postfixLength = prefixString.length == 1 ? `000${prefixString}` : prefixString.length == 2 ? `00${prefixString}` : prefixString.length == 3 ? `0${prefixString}` : prefixString.length == 4 ? `${prefixString}` : prefixString
    let uniqueid = Math.random().toFixed(5);
    setCounters([...counters, { counterid: postfixLength, countername: "", _id: uniqueid, newAdded: true }])
  }

  function multiCounterInputs(referenceId, reference, inputvalue) {
    if (reference == "counterName") {
      let counterNameInput = counters.map((value, index) => {
        if (referenceId == value._id) {
          return { ...value, countername: inputvalue }
        }
        else {
          return value;
        }
      });
      return setCounters(counterNameInput);
    }

  }



  const deleteCounter = (referenceIndex) => {
    let prefixLength = Number(subStringVal) - 1;
    let prefixString = String(prefixLength);
    let rdata = prefixString.length == 1 ? `000${prefixString}` : prefixString.length == 2 ? `00${prefixString}` : prefixString.length == 3 ? `0${prefixString}` : prefixString
    setSubStringVal(rdata);
    let deleteIndex;

    let subCategoryData = counters.filter((value, index) => {
      if (referenceIndex != value._id) {

        return value;
      } else {
        if (counters[index + 1]) {
          deleteIndex = index;
        }
      }
      return false;
    });

  
    let resultData = subCategoryData.map((data, index) => {
      if (index >= deleteIndex) {
        let counterstart = data.counterid
        let codenum = counterstart.slice(2);
        let prefixLength = Number(codenum) - 1;
        let prefixString = String(prefixLength);
        let postfixLength = prefixString.length == 1 ? `000${prefixString}` : prefixString.length == 2 ? `00${prefixString}` : prefixString.length == 3 ? `0${prefixString}` : prefixString


        return { ...data, counterid: postfixLength, }
      } else {
        return data;
      }
    })
   setCounters(resultData);
  }




  // const deleteCounter = (referenceId) => {



  //   let counterdata = counters.filter((value, index) => {
  //     if (referenceId != value._id) {
  //       return value;
  //     }
  //   });
  //   setCounters(counterdata);


  // }

  return (
    <Box>
      {counters.length >= 0 && (
        <ul type="none" className="todoLlistUl" style={{ paddingLeft: '0px', marginLeft: '0px' }}>
          {counters.map((item, index) => {
            return (
              <li key={index}>
                <br />
                <Grid container columnSpacing={1}>
                  <Grid item sm={12} xs={12} md={5} lg={5}>
                    <InputLabel htmlFor="component-outlined">Counter No</InputLabel>
                    <FormControl size="small" fullWidth>
                      <OutlinedInput
                        id="component-outlined"
                        value={item.countername}
                        onChange={(e) => multiCounterInputs(item._id, "counterName", e.target.value)}
                        type="text"
                        name="countername"
                        placeholder="Counter No"
                      />
                    </FormControl>
                  </Grid>
                  <Grid item sm={12} xs={12} md={5} lg={5}>
                    <InputLabel htmlFor="component-outlined">Counter ID</InputLabel>
                    <FormControl size="small" fullWidth>
                      <OutlinedInput
                        id="component-outlined"
                        value={item.counterid}
                        type="text"
                        name="counterid"
                        placeholder="Counter ID"
                      />
                    </FormControl>
                  </Grid>
                  <Grid item sm={1} xs={1} md={2} lg={2} sx={{ display: 'flex' }}>
                    <Button variant="contained" color="success" type="button" onClick={() => addCounter()} sx={userStyle.categoryadd}><FaPlus /></Button>&nbsp;
                    {index !== 0 && <Button variant="contained" color="error" type="button" onClick={(e) => deleteCounter(item._id)} sx={userStyle.categoryadd}><AiOutlineClose /></Button>}
                  </Grid>
                </Grid>
              </li>
            )
          })}
        </ul>
      )
      }
    </Box>
  );
}