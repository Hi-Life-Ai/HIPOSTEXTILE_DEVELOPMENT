export const SidebarItems = [
    {
        id: 1,
        label: 'Home',
        dbname:'home',
        route: '/',
    },
    {
        id: 2,
        label: 'User Management',
        dbname:'usermanagement',
        name : 'user',
        children: [
            {
                id: 1,
               
                label: 'User',
                dbname:'alluser',
                route: '/user/user/list',
            },
            {
                id: 2,
               
                label: 'Role',
                dbname: 'allrole',
                route: '/user/role/list',
            },
            {
                id: 3,
                label: 'Department',
                dbname: 'alldepartment',
                route: '/user/department/list',
            }
        ]
    },
    {
        id: 3,
       
        label: 'Suppliers',
        dbname:'suppliermanagement',
       
        name: 'contact',
        children: [
            {
                id: 1,
               
                label: 'Add Suppliers',
                dbname:'asupplier',
                route: '/contact/supplier/create',
            },
            {
                id: 2,
               
                label: 'Import Suppliers',
                dbname:'isupplier',
                route: '/contact/supplier/import',
            },
            {
                id: 3,
               
                label: 'List Suppliers',
                dbname:'allsupplier',
                route: '/contact/supplier/list',
            },
        ]
    },
    {
        id: 4,
       
        label: 'Customers',
        dbname:'customermanagement',
       
        name: 'contact',
        children: [
            {
                id: 1,
               
                label: 'Add Customers',
                dbname:'acustomer',
                route: '/contact/customer/create',
            },
            {
                id: 2,
               
                label: 'Import Customers',
                dbname:'icustomer',
                route: '/contact/customer/import',
            },
            {
                id: 3,
               
                label: 'List Customers',
                dbname:'allcustomer',
                route: '/contact/customer/list',
            },
            {
                id: 4,
               
                label: 'List Customer Group',
                dbname:'allcustomergrp',
                route: '/contact/customergroup/list',
            }
        ]
    },
    {
        id:5,
        label: 'Products',
        dbname:'productmanagement',
        name: 'product',
        children:[
            {
                id: 1,
               
                label: 'Size',
                dbname:'allsize',
                route: '/product/size/list',
            },
            {
                id: 2,
               
                label: 'Units',
                dbname:'allunit',
                route: '/product/unit/list',
            },
            {
                id:3,
               
                label: 'Color',
                dbname:'allcolor',
                route: '/product/color/list',
            },
            {
                id: 4,
               
                label: 'Category',
                dbname:'allcategory',
                route: '/product/category/list',
            },
            {
                id: 5,
               
                label: 'Add products',
                dbname:'aproduct',
                route: '/product/product/create',
            },
            {
                id: 6,
               
                label: 'Import Products',
                dbname:'iproduct',
                route: '/product/importproducts',
            },
            {
                id: 7,
               
                label: 'List Product',
                dbname:'allproduct',
                route: '/product/product/list',
            },
            {
                id: 8,
               
                label: 'Discount',
                dbname:'alldiscount',
                route: '/product/discount/list',
            },
            {
                id: 9,
               
                label: 'Stock',
                dbname:'allstock',
                route: '/product/stock/list',
            },
            {
                id: 10,
               
                label: 'Print Labels',
                dbname:'allproductlabel',
                route: '/product/printlabel',
            },
        ]
    },
    {
        id: 6,
       
        label: 'Purchases',
        dbname:'purchasemanagement',
       
        name: 'purchase',
        children:[
            {
                id: 1,
               
                label: 'Add Purchase',
                dbname:'apurchase',
                route: '/purchase/purchase/create',
            },
            {
                id: 2,
               
                label: 'List Purchase',
                dbname:'allpurchase',
                route: '/purchase/purchase/list',
            },
            {
                id: 2,
               
                label: 'Purchase Return',
                dbname:'allpurchase',
                route: '/purchase/purchasereturn/list',
            },
        ]
    },
    {
        id: 7,
        
        label: 'Sell',
        dbname:'sellmanagement',
       
        name: 'sell',
        children: [
            {
                id: 1,
               
                label: 'POS',
                dbname:'apos',
                route: '/sell/pos/create',
            },
            {
                id: 2,
               
                label: 'List POS',
                dbname:'allpos',
                route: '/sell/pos/list',
            },
            {
                id: 3,
               
                label: 'List Drafts',
                dbname:'alldraft',
                route: '/sell/draft/list',
            },
            {
                id: 4,
               
                label: 'List Quatations',
                dbname:'allquotation',
                route: '/sell/quotation/list',
            },
        ]
    },
    {
        id: 8,
        label: 'Expenses',
        dbname:'expensemanagement',
        name: 'expenses',
        children: [
            {
                id: 1,
               
                label: 'Add Expenses',
                dbname:'aexpense',
                route: '/expense/expense/create',
            },
            {
                id: 2,
               
                label: 'List Expenses',
                dbname:'allexpense',
                route: '/expense/expense/list',
            },
            {
                id: 3,
               
                label: 'Expenses Categories',
                dbname:'allexpensecategory',
                route: '/expense/expensecategory/list',
            }
        ]
    },
    {
        id: 9,
        label: 'Stock Transfer',
        dbname:'allstocktransferlist',
        route: '/stocktransfer/list',
    },
    {
        id: 10,
        label: 'Stock Adjust',
        dbname:'stockadjustmanagement',
        route: '/stockadjust/list',
    },
    {
        id: 11,
        label: 'Passwords',
        dbname:'passwordmanagement',
        name: 'password',
        children: [
            {
                id: 1,
                label: 'Add Password',
                dbname:'apassword',
                route: '/passwords/password/create',
            },
            {
                id: 2,
                label: 'List Passwords',
                dbname:'allpassword',
                route: '/passwords/password/list',
            },
            {
                id: 3,
                label: 'Add Folder',
                dbname:'vfolder',
                route: '/passwords/folder/list',
            },
            {
                id: 4,
                label: 'Assign Password',
                dbname:'allassignpassword',
                route: '/passwords/assignpassword/create',
            },
            {
                id: 5,
                label: 'User Password',
                dbname:'assignpasswordlist',
                route: '/passwords/assignpassword/list',
            },
        ]
    },
    {
        id: 12,
      
        label: 'Settings',
        dbname:'settingsmanagement',
       
        name: 'setting',
        children: [
            {
                id: 1,
               
                label: 'Business Settings',
                dbname:'businesssettings',
                route: '/settings/business/list',
            },
            {
                id: 2,
               
                label: 'Business Location',
                dbname:'allbusinesslocation',
                route: '/settings/location/list',
            },
            {
                id: 3,
               
                label: 'Alpharate',
                dbname:'allalpharate',
                route: '/settings/alpharate/list',
            },
            {
                id: 4,
               
                label: 'Tax Rates',
                dbname:'alltaxrate',
                route: '/settings/taxrate/list',
            },
            {
                id: 5,
               
                label: 'Payment Integration',
                dbname:'allpaymentintegration',
                route: '/settings/paymentintegration/list',
            }
        ]
    },
    
]

